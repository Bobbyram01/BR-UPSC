# BR UPSC CSE 2028 Tracker

A responsive web dashboard for the UPSC CSE 2028 study roadmap, syllabus progress, daily routine, Prelims and Mains tests, and calendar schedule starting 20 October 2026.

This folder is a complete Hatchable project. Everything the app needs is in these files: pages, API routes, database migrations, seed data, and the hatchable.toml manifest that declares the services and keys it uses.

## Run your own copy

1. Go to https://hatchable.com/deploy
2. Bring this folder as a .zip, or point the importer at a Git repository that contains it
3. Your copy gets its own database, its own URL, and connects to your own keys

## About Hatchable

Hatchable is where AI-built apps go live. Connect the AI you already use and it can build, deploy, and run apps like this one for you.

Built on Hatchable. https://hatchable.com

import { db } from 'hatchable';

export const access = 'user';
export const methods = ['GET', 'PUT'];

export default async function (req, res) {
  const userId = req.user.id;
  if (req.method === 'GET') {
    const result = await db.query('SELECT state, updated_at FROM tracker_sync WHERE user_id = $1', [userId]);
    if (!result.rows.length) return res.json({ exists: false, state: null, updatedAt: null });
    return res.json({ exists: true, state: result.rows[0].state, updatedAt: result.rows[0].updated_at });
  }
  const state = req.body && req.body.state;
  if (!state || typeof state !== 'object' || Array.isArray(state)) return res.status(400).json({ error: 'A tracker state object is required.' });
  const encoded = JSON.stringify(state);
  if (encoded.length > 900000) return res.status(413).json({ error: 'Tracker data is too large to sync. Remove large embedded images from your profile and retry.' });
  const result = await db.query(
    'INSERT INTO tracker_sync (user_id, state, updated_at) VALUES ($1, $2::jsonb, now()) ON CONFLICT (user_id) DO UPDATE SET state = EXCLUDED.state, updated_at = now() RETURNING updated_at',
    [userId, encoded]
  );
  return res.json({ ok: true, updatedAt: result.rows[0].updated_at });
}
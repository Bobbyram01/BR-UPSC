export const methods = ['GET'];
export const access = 'public';
const FEEDS = [
  ['BBC World','https://feeds.bbci.co.uk/news/world/rss.xml'],
  ['UN News','https://news.un.org/feed/subscribe/en/news/all/rss.xml'],
  ['NASA','https://www.nasa.gov/news-release/feed/'],
  ['PIB India','https://pib.gov.in/RssMain.aspx?ModId=6&Lang=1&Regid=3']
];
function decode(s=''){return s.replace(/<!\[CDATA\[([\s\S]*?)\]\]>/g,'$1').replace(/<[^>]+>/g,' ').replace(/&amp;/g,'&').replace(/&quot;/g,'"').replace(/&#39;|&apos;/g,"'").replace(/&lt;/g,'<').replace(/&gt;/g,'>').replace(/&#(\d+);/g,(_,n)=>String.fromCharCode(+n)).replace(/\s+/g,' ').trim();}
function items(xml,source){return [...xml.matchAll(/<item\b[^>]*>([\s\S]*?)<\/item>/gi)].slice(0,12).map(m=>{const x=m[1],get=t=>(x.match(new RegExp('<'+t+'\\b[^>]*>([\\s\\S]*?)<\\/'+t+'>','i'))||[])[1]||'';return {title:decode(get('title')),link:decode(get('link')),published:decode(get('pubDate')||get('dc:date')),summary:decode(get('description')).slice(0,360),source};}).filter(a=>a.title&&a.link);}
export default async function(req,res){const results=await Promise.all(FEEDS.map(async([source,url])=>{try{const r=await fetch(url,{headers:{'user-agent':'BR-UPSC-Current-Affairs/1.0'},signal:AbortSignal.timeout(8000)});if(!r.ok)throw new Error('feed unavailable');return items(await r.text(),source);}catch{return []}}));const all=results.flat().sort((a,b)=>new Date(b.published||0)-new Date(a.published||0));res.setHeader('Cache-Control','public, max-age=900');res.json({updatedAt:new Date().toISOString(),items:all.slice(0,32),sources:FEEDS.map(f=>f[0]),note:all.length?'Headlines from linked publisher feeds. Open the source before using a story in an answer.':'News feeds are temporarily unavailable. Please retry later.'});}